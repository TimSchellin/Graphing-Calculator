#include "Token.h"
#include "StringToQueue.h"
#include "ShuntingYard2.h"
#include "Interface.h"

#include <iostream>
#include <cmath>
#include <cassert>
#include <SFML/Graphics.hpp>
#include "StringToShunting.h"
#include <stdio.h>


void pause();
void menu();

using namespace std;
using namespace sf;

extern vector<String> functions;

int main()
{
	menu();
	Interface gui;
	gui.run();
	pause();
}

void pause() {
	int i;
	cin >> i;
}

void menu() {
	int num = 0;
	cout << "how many functions would you like to input? > ";
	cin >> num;
	cout << "\n\n";
	for (int i = 0; i < num; i++) {
		std::string temp;
		cout << "enter function " << i << " > ";
		cin >> temp;
		functions.push_back(static_cast<String>(temp));
	}
}

void testRPN() {
	String testString = "3*8+2";
	double answer = te_interp("3*2+4*1+(4+9)*6", 0);
	printf("Answer is %f\n", answer);
}