#ifndef STOREDFUNCTIONS_H
#define STOREDFUNCTIONS_H

#include "UserFunction.h"
#include "Dimensions.h"
#include <SFML/Graphics.hpp>
#include <iostream>

using namespace sf;
using namespace std;

/*
Vector2f getCellPosition() {
	return (Vector2f(0, BANNER_HEIGHT + userFunctions.size()*CELL_HEIGHT));
}
*/
#endif